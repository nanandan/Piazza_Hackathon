var map = {"in javascript - sort algorithm?":"nebumewobi-6764@yopmail.com","Use VB.net to drop files in third-party window":"lettipiqu-3307@yopmail.com", "Security Access Denied Exception, WCF Trace , Reemote debugging":"offylluzo-5101@yopmail.com", 
"Spreadsheet using JavaScript no HTML defined in body (Two Functions: Sum and AVG)":"uttottalu-1799@yopmail.com", "zesucequff-5879@yopmail.com":"felebydede-1948@yopmail.com", "Error in Stratified sampling.":"towezodann-4591@yopmail.com", "Get and Check Table Every Row Height Optimal Way":"fuddydemmadda-7312@yopmail.com", 
"Unmarshal() is returning empty structs":"ettufattyru-6259@yopmail.com", "Meteor - ViewModel link to collection":"sexomorro-4810@yopmail.com", 
"SecurityAccessDenied Exception, WCF Trace , Reemote debugging":"vewassexuv-8509@yopmail.com", "More beneficial way than thread a column in mysql":"qesommuddu-4437@yopmail.com"};


module.exports = function(){
	return map;
}